RTM Klik Channels List

(FORMAT: XMLTV ID: CHANNEL NAME)

- RTMK01: TV1
- RTMK02: TV2
- RTMK03: TV Okey
- RTMK04: Berita RTM
- RTMK05: TV Sukan (RTM Sports HD)
- RTMK06: TV6
- RTMK07: Dewan Rakyat
- RTMK08: Dewan Negara