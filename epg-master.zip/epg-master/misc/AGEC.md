Astro GO Exclusive Channels Channel List

(FORMAT: XMLTV ID: CHANNEL NAME)

- AGEC1: K-Plus HD
- AGEC2: DW English
- AGEC3: France24 English